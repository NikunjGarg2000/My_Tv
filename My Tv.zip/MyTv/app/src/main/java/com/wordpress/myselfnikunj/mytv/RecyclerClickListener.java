package com.wordpress.myselfnikunj.mytv;

import android.view.View;

public interface RecyclerClickListener {
    void onItemClickListener(View view, int pos);
}

